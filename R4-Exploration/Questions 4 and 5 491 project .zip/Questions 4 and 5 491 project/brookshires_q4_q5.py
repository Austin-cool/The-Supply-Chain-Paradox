"""Brookshire's Q4/Q5 reproducible cleaning + exploratory analysis.

Q4: How does opening stock differ between products inferred on/off sale?
Q5: When are gross margins lowest: all ad weeks or holiday/big-sale weeks?

Usage (from folder with original files):
  py -m pip install pandas numpy matplotlib
  py brookshires_q4_q5.py

Source files are NEVER overwritten. Inferred promotion and holiday labels are
proxies, not known advertising events. Association is not causation.
"""
from __future__ import annotations
import argparse
import gc
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

FILES = ['calendar.csv','stores.csv','products.csv','prices.csv',
         'sales_train.csv.gz','inventory.csv.gz']
TYPE_ORDER = ['Low-promotion','Other ad week','Candidate big-sale']
MAJOR_HOLIDAY_EVENTS = {'Thanksgiving','Christmas','NewYear','Easter','IndependenceDay'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data-dir', type=Path, default=Path(__file__).resolve().parent,
                        help='Folder containing the original six CSV files')
    parser.add_argument('--output-dir', type=Path, default=None,
                        help='Output folder (default: DATA_DIR/brookshires_q4_q5_results)')
    parser.add_argument('--export-cleaned', action='store_true',
                        help='Also save clean_products.csv and large row-level cleaned prices, sales and inventory .csv.gz files')
    parser.add_argument('--discount-threshold',type=float,default=0.05,
                        help='Inferred discount threshold; 0.05 is 5%% (default)')
    args = parser.parse_args()
    root = args.data_dir.resolve()
    out = (args.output_dir or (root/'brookshires_q4_q5_results')).resolve()
    out.mkdir(parents=True,exist_ok=True)
    for filename in FILES:
        if not (root/filename).is_file():
            parser.error(f'Missing {filename} in {root}')
    audit=[]
    checks=[]
    def step(filename, action, before, after, affected, reason):
        rec={'file':filename,'cleaning_action':action,'rows_before':int(before),
             'rows_after':int(after),'rows_affected':int(affected),'reason':reason}
        audit.append(rec)
        print(f"  {filename}: {action} — {affected:,} rows affected; {before:,} -> {after:,}",flush=True)
    def check(filename, issue, count, note=''):
        checks.append({'file':filename,'quality_check':issue,'affected_rows':int(count),'note':note})
        print(f'  CHECK {filename}: {issue}: {int(count):,}',flush=True)

    print('STEP 1 — Load dimensions and validate',flush=True)
    cal=pd.read_csv(root/'calendar.csv')
    stores=pd.read_csv(root/'stores.csv')
    products=pd.read_csv(root/'products.csv',dtype={'upc':'string'})
    prices=pd.read_csv(root/'prices.csv',dtype={'store_id':'int16','item_id':'int32','ad_week':'int32','sell_price':'float32'})
    for name, df, key in [('calendar.csv',cal,['date']),('stores.csv',stores,['store_id']),
                          ('products.csv',products,['item_id']),('prices.csv',prices,['store_id','item_id','ad_week'])]:
        print(f'  {name}: {len(df):,} original rows',flush=True)
        duplicates=int(df.duplicated(key).sum())
        check(name,'duplicate business-key rows',duplicates)
        if duplicates:
            raise ValueError(f'{name} contains duplicate keys. Review instead of arbitrarily keeping one.')
        step(name,'read / retain valid key rows',len(df),len(df),0,'No key rows removed')

    check('products.csv','missing unit_cost',products.unit_cost.isna().sum(),
          'Do not invent a cost; exclude these product sales from margin calculations only')
    check('products.csv','invalid UPC (12 digits including leading zero)',
          (~products.upc.fillna('').str.fullmatch(r'\d{12}')).sum())
    check('products.csv','nonpositive case_pack',(products.case_pack<=0).sum())

    # Trim only leading/trailing whitespace: preserve spaces within names.
    # Record affected rows before changing any values, including the union
    # (a product with both fields affected must be counted only once).
    whitespace_flags = pd.Series(False, index=products.index)
    for column in ('department', 'category'):
        original_values = products[column]
        trimmed_values = original_values.str.strip()
        affected_mask = original_values.notna() & original_values.ne(trimmed_values)
        affected_count = int(affected_mask.sum())
        whitespace_flags |= affected_mask
        check('products.csv', f'leading/trailing whitespace in {column}', affected_count,
              'Trim with str.strip(); keep internal spaces unchanged')
        products[column] = trimmed_values
        step('products.csv', f'trim leading/trailing whitespace from {column}',
             len(products), len(products), affected_count,
             'Normalize text used to group product department/category; no product rows removed')
    check('products.csv', 'unique products with whitespace in department or category',
          int(whitespace_flags.sum()), 'Combined unique rows; not necessarily the sum of column counts')
    if args.export_cleaned:
        products.to_csv(out/'clean_products.csv', index=False)

    check('calendar.csv','unexpected date format',(~cal.date.astype(str).str.fullmatch(r'\d{4}-\d{2}-\d{2}')).sum())
    check('prices.csv','missing/nonpositive price',(prices.sell_price.isna()|(prices.sell_price<=0)).sum())
    if not (prices.sell_price>0).all():
        raise ValueError('Nonpositive prices need manual review')
    for col,valid,name in [('store_id',stores.store_id,'stores.csv'),('item_id',products.item_id,'products.csv'),('ad_week',cal.ad_week,'calendar.csv')]:
        check('prices.csv',f'unknown {col}',(~prices[col].isin(valid)).sum(),f'Not found in {name}')

    # Identify unusually large store-wide prices, then validate against other stores' medians.
    store_medians=prices.groupby('store_id').sell_price.median()
    typical_median=float(store_medians.median())
    price_scale_store_ids=store_medians.index[store_medians>typical_median*50].tolist()
    scale_mask=prices.store_id.isin(price_scale_store_ids)
    check('prices.csv','probable cents-as-dollars rows',scale_mask.sum(),
          f'Outlier store IDs: {price_scale_store_ids}. Values divided by 100; requires source confirmation')
    step('prices.csv','divide price by 100 for flagged stores',len(prices),len(prices),int(scale_mask.sum()),
         'Store-wide median over 50x typical store price; probable cents/dollars mismatch')
    prices.loc[scale_mask,'sell_price']=(prices.loc[scale_mask,'sell_price']/100).round(2)
    prices['reference_price']=prices.groupby(['store_id','item_id']).sell_price.transform('median')
    prices['discount_pct']=(1-prices.sell_price/prices.reference_price).clip(lower=0)
    prices['on_sale_inferred']=prices.discount_pct >= args.discount_threshold
    prices['ad_zone']=prices.store_id.map(stores.set_index('store_id').ad_zone)
    step('prices.csv','infer sale flag from two-year store-item median',len(prices),len(prices),
         int(prices.on_sale_inferred.sum()),
         f'Inferred if sell_price <= (1 - {args.discount_threshold}) times store/product historical median')
    zone_week=(prices.groupby(['ad_zone','ad_week'],observed=True)
          .agg(share_on_sale=('on_sale_inferred','mean'),mean_discount=('discount_pct','mean'))
          .reset_index())
    zone_week['breadth_rank']=zone_week.groupby('ad_zone').share_on_sale.rank(method='first',pct=True)
    zone_week['week_type']=np.select([zone_week.breadth_rank<=.20,zone_week.breadth_rank>.80],
                ['Low-promotion','Candidate big-sale'],default='Other ad week')
    if args.export_cleaned:
        prices.to_csv(out/'clean_prices.csv.gz',index=False,compression={'method':'gzip','compresslevel':1})
    zone_week.to_csv(out/'inferred_promotion_weeks.csv',index=False)

    cal['day_id']=np.arange(len(cal),dtype=np.int16)
    datestr=cal.date.astype(str)
    date_to_day=cal.set_index('date').day_id
    date_to_week=cal.set_index('day_id').ad_week
    slash_to_iso=dict(zip(pd.to_datetime(datestr).dt.strftime('%m/%d/%Y'),datestr))
    cal['major_holiday_date']=cal.event_name_1.isin(MAJOR_HOLIDAY_EVENTS) | cal.event_name_2.isin(MAJOR_HOLIDAY_EVENTS)
    cal['national_religious_date']=cal.event_type_1.isin(['National','Religious']) | cal.event_type_2.isin(['National','Religious'])
    holidays=(cal.groupby('ad_week').agg(
        major_holiday_week=('major_holiday_date','any'),
        national_religious_week=('national_religious_date','any'),
        first_date=('date','min'),last_date=('date','max')).reset_index())
    names=cal.loc[cal.event_name_1.isin(MAJOR_HOLIDAY_EVENTS),['ad_week','event_name_1']].copy()
    holidays['major_holiday_names']=holidays.ad_week.map(names.groupby('ad_week').event_name_1.agg('; '.join)).fillna('')
    holidays.to_csv(out/'calendar_week_holidays.csv',index=False)
    christmas_ids=set(cal.loc[datestr.str.endswith('-12-25'),'day_id'])

    print('STEP 2 — Clean sales rows',flush=True)
    sales=pd.read_csv(root/'sales_train.csv.gz',dtype={'store_id':'int16','item_id':'int32','unit_sales':'int32'})
    before=len(sales)
    slash=sales.date.str.contains('/',regex=False)
    sales.loc[slash,'date']=sales.loc[slash,'date'].map(slash_to_iso)
    check('sales_train.csv.gz','MM/DD/YYYY dates',slash.sum())
    step('sales_train.csv.gz','normalize dates to YYYY-MM-DD',before,len(sales),int(slash.sum()),
         'Use calendar lookup rather than ambiguous date parsing')
    invalid_dates=(~sales.date.isin(cal.date))
    check('sales_train.csv.gz','date outside calendar / invalid',invalid_dates.sum())
    if invalid_dates.any():
        raise ValueError('Invalid dates in sales, inspect before proceeding')
    bad_keys=sales.duplicated(['date','store_id','item_id'],keep=False)
    exact_dupes=int(sales.duplicated().sum())
    nonexact_conflicts=int(sales.loc[bad_keys].drop_duplicates().duplicated(['date','store_id','item_id'],keep=False).sum())
    check('sales_train.csv.gz','extra exact duplicate rows',exact_dupes)
    check('sales_train.csv.gz','conflicting duplicate key rows',nonexact_conflicts)
    if nonexact_conflicts:
        raise ValueError('Conflicting duplicate sales keys; cannot safely select record')
    old_n=len(sales)
    sales.drop_duplicates(inplace=True)
    step('sales_train.csv.gz','remove exact duplicate rows',old_n,len(sales),old_n-len(sales),
         'Only repeat identical records, no aggregation')
    max_valid_daily_units=500  # analyst-chosen flag: unusual, NOT a proven physical limit
    sales['valid_sales']=sales.unit_sales<=max_valid_daily_units
    bad_units=int((~sales.valid_sales).sum())
    check('sales_train.csv.gz',f'unit_sales above {max_valid_daily_units}',bad_units,
          'Retain row and original value; EXCLUDE from numeric sales/margin analysis, do not replace by zero')
    check('sales_train.csv.gz','negative unit_sales (permitted returns)',(sales.unit_sales<0).sum())
    step('sales_train.csv.gz','flag extreme quantities for exclusion',len(sales),len(sales),bad_units,
         'Keep original rows; mark valid_sales=False; totals omit invalid values')
    sales['day_id']=sales.date.map(date_to_day).astype('int16')
    sales['ad_week']=sales.day_id.map(date_to_week).astype('int32')
    for col,valid in [('store_id',stores.store_id),('item_id',products.item_id)]:
        check('sales_train.csv.gz',f'unknown {col}',(~sales[col].isin(valid)).sum())
    if args.export_cleaned:
        sales.to_csv(out/'clean_sales.csv.gz',index=False,compression={'method':'gzip','compresslevel':1})
    # Keep minimal memory for analysis; retain source unit_sales plus exclusion flag.
    sales.drop(columns=['date'],inplace=True)

    print('STEP 3 — Inspect inventory and its relationship to sales',flush=True)
    inv=pd.read_csv(root/'inventory.csv.gz',dtype={'store_id':'int16','item_id':'int32','on_hand':'int32','received':'int32','shrink':'int32'})
    for field in ('on_hand','received','shrink'):
        check('inventory.csv.gz',f'negative {field}',(inv[field]<0).sum())
    check('inventory.csv.gz','duplicate store/date/item key',inv.duplicated(['date','store_id','item_id']).sum())
    check('inventory.csv.gz','unknown dates',(~inv.date.isin(cal.date)).sum())
    if any((inv[c]<0).any() for c in ('on_hand','received','shrink')):
        raise ValueError('Invalid negative inventory counts')
    if inv.duplicated(['date','store_id','item_id']).any():
        raise ValueError('Inventory duplicate keys need manual review')
    inv['day_id']=inv.date.map(date_to_day).astype('int16')
    cp=products.set_index('item_id').case_pack
    case_pack=inv.item_id.map(cp)
    check('inventory.csv.gz','delivery not multiple of case_pack',
          ((inv.received>0)&(inv.received%case_pack!=0)).sum())
    step('inventory.csv.gz','validate inventory (no rows dropped)',len(inv),len(inv),0,
         'Preserve stock as observed; no smoothing of stockouts')
    if args.export_cleaned:
        inv.to_csv(out/'clean_inventory.csv.gz',index=False,compression={'method':'gzip','compresslevel':1})
    inv.drop(columns=['date'],inplace=True)

    print('STEP 4 — Compare Q4 (on-sale and off-sale) and Q5 (week + holiday)',flush=True)
    lookup_cost=products.set_index('item_id').unit_cost
    dept=products.set_index('item_id').department
    zone_by_store=stores.set_index('store_id').ad_zone
    q4_parts=[]; q4_depts=[]; store_days=[]
    balance_bad=0; balance_tested=0; over_stock=0; missing_inv=0; margin_excluded_no_cost=0; margin_excluded_bad_sales=0
    for store_id in stores.store_id:
        sid=int(store_id)
        print(f'  Analyzing store {sid}',flush=True)
        xs=sales.loc[sales.store_id==sid,['item_id','day_id','ad_week','unit_sales','valid_sales']]
        xi=inv.loc[inv.store_id==sid,['item_id','day_id','on_hand','received','shrink']]
        xp=prices.loc[prices.store_id==sid,['item_id','ad_week','sell_price','on_sale_inferred']]
        x=xs.merge(xp,on=['item_id','ad_week'],how='left',validate='many_to_one')
        x=x.merge(xi,on=['day_id','item_id'],how='left',validate='one_to_one')
        missing_inv+=int(x.on_hand.isna().sum())
        if x.on_hand.isna().any() or x.sell_price.isna().any():
            raise ValueError(f'Missing inventory or price in store {sid}; audit before analyzing')
        # Continuity check across adjacent days with valid previous sales.
        x.sort_values(['item_id','day_id'],inplace=True)
        g=x.groupby('item_id',sort=False)
        previous_day=g.day_id.shift()
        previous_valid=g.valid_sales.shift(fill_value=False).astype(bool)
        comparable=(x.day_id-previous_day==1)&previous_valid
        expected=g.on_hand.shift()-g.unit_sales.shift().clip(lower=0)-g.shrink.shift()+x.received
        balance_tested+=int(comparable.sum())
        balance_bad+=int((comparable&(x.on_hand!=expected)).sum())
        over_stock+=int(((x.unit_sales>x.on_hand)&x.valid_sales).sum())
        del g,previous_day,previous_valid,comparable,expected
        # Closed Christmas days are not comparable selling days.
        x=x.loc[~x.day_id.isin(christmas_ids)].copy()
        zone=zone_by_store.loc[sid]
        zone_map=zone_week.loc[zone_week.ad_zone==zone].set_index('ad_week').week_type
        x['week_type']=x.ad_week.map(zone_map)
        x['department']=x.item_id.map(dept)
        x['unit_cost']=x.item_id.map(lookup_cost)
        x['has_valid_cost']=x.unit_cost.notna()&(x.unit_cost>0)
        good=x.valid_sales&x.has_valid_cost
        margin_excluded_no_cost+=int((~x.has_valid_cost).sum())
        margin_excluded_bad_sales+=int((~x.valid_sales & x.has_valid_cost).sum())
        # Intentionally leave missing margin NaN until aggregation.
        x['gross_margin']=np.where(good,x.unit_sales*(x.sell_price-x.unit_cost),np.nan)
        x['revenue']=np.where(good,x.unit_sales*x.sell_price,np.nan)
        x['opening_zero']=(x.on_hand==0).astype('int8')
        x['clean_units']=x.unit_sales.where(x.valid_sales,np.nan)
        q4_parts.append(x.groupby(['week_type','on_sale_inferred'],observed=True).agg(
            product_days=('day_id','size'),zero_openings=('opening_zero','sum'),
            total_opening_stock=('on_hand','sum'),delivered_units=('received','sum'),
            valid_sales_units=('clean_units','sum')).reset_index())
        q4_depts.append(x.groupby(['department','week_type','on_sale_inferred'],observed=True).agg(
            product_days=('day_id','size'),zero_openings=('opening_zero','sum'),
            total_opening_stock=('on_hand','sum'),delivered_units=('received','sum')).reset_index())
        daily=x.groupby(['day_id','ad_week','week_type'],observed=True).agg(
            total_margin=('gross_margin','sum'),total_revenue=('revenue','sum'),
            products_with_valid_margin=('gross_margin','count'),valid_units=('clean_units','sum')).reset_index()
        daily['store_id']=sid
        store_days.append(daily)
        del x,daily,xs,xi,xp
        gc.collect()
    check('inventory.csv.gz','missing matching inventory rows for sales',missing_inv)
    check('inventory.csv.gz','inventory-balance mismatches',balance_bad,
          f'Among {balance_tested:,} consecutive-day comparisons, excluding extreme predecessor sales')
    check('inventory.csv.gz','valid daily units sold greater than opening stock',over_stock)
    step('sales_train.csv.gz','exclude rows from margin due to missing cost',len(sales),len(sales),margin_excluded_no_cost,
         'Product-days with no unit_cost, not dropped from Q4')
    step('sales_train.csv.gz','exclude additional rows from margin due to extreme sales',len(sales),len(sales),margin_excluded_bad_sales,
         'Keep original rows and omit these product-day margin values')

    def make_q4(parts, group):
        combined=pd.concat(parts,ignore_index=True)
        fields=['product_days','zero_openings','total_opening_stock','delivered_units']
        if 'valid_sales_units' in combined:fields.append('valid_sales_units')
        r=combined.groupby(group,observed=True)[fields].sum().reset_index()
        r['opening_zero_pct']=100*r.zero_openings/r.product_days
        r['mean_opening_stock']=r.total_opening_stock/r.product_days
        r['mean_received_units']=r.delivered_units/r.product_days
        if 'valid_sales_units' in r:r['mean_valid_units_sold']=r.valid_sales_units/r.product_days
        return r
    q4=make_q4(q4_parts,['week_type','on_sale_inferred'])
    q4_dept=make_q4(q4_depts,['department','week_type','on_sale_inferred'])
    q4.to_csv(out/'q4_on_sale_vs_not_on_sale.csv',index=False)
    q4_dept.to_csv(out/'q4_by_department.csv',index=False)

    sd=pd.concat(store_days,ignore_index=True)
    sd['date']=sd.day_id.map(cal.set_index('day_id').date)
    sd['ad_zone']=sd.store_id.map(zone_by_store)
    sd=sd.merge(holidays[['ad_week','major_holiday_week','national_religious_week','major_holiday_names']],
        on='ad_week',how='left',validate='many_to_one')
    sd['margin_rate_pct']=100*sd.total_margin/sd.total_revenue.replace(0,np.nan)
    sd.to_csv(out/'q5_store_day_margins.csv',index=False)

    def margin_summary(gcols):
        r=sd.groupby(gcols,observed=True).agg(
            store_open_days=('date','size'),mean_gross_margin_per_store_day=('total_margin','mean'),
            median_gross_margin_per_store_day=('total_margin','median'),
            total_gross_margin=('total_margin','sum'),total_revenue=('total_revenue','sum'),
            mean_units_per_store_day=('valid_units','mean')).reset_index()
        r['gross_margin_rate_pct']=100*r.total_gross_margin/r.total_revenue.replace(0,np.nan)
        return r
    q5=margin_summary(['week_type'])
    q5h=margin_summary(['major_holiday_week','week_type'])
    q5b=margin_summary(['major_holiday_week'])
    q5_zone=margin_summary(['ad_zone','week_type'])
    q5.to_csv(out/'q5_by_promotion_intensity.csv',index=False)
    q5h.to_csv(out/'q5_holiday_x_promotion.csv',index=False)
    q5b.to_csv(out/'q5_holiday_vs_other_weeks.csv',index=False)
    q5_zone.to_csv(out/'q5_by_ad_zone.csv',index=False)
    weekly=(sd.groupby('ad_week').agg(
        total_margin=('total_margin','sum'),total_revenue=('total_revenue','sum'),
        store_open_days=('store_id','size')).reset_index().merge(holidays,on='ad_week',how='left'))
    weekly['margin_per_store_open_day']=weekly.total_margin/weekly.store_open_days
    weekly['margin_rate_pct']=100*weekly.total_margin/weekly.total_revenue.replace(0,np.nan)
    weekly.to_csv(out/'q5_weekly_margin_with_holidays.csv',index=False)
    pd.DataFrame(audit).to_csv(out/'cleaning_log_before_after.csv',index=False)
    pd.DataFrame(checks).to_csv(out/'data_quality_counts.csv',index=False)

    print('STEP 5 — Generate graphs',flush=True)
    # Q4 core requested sale/not-sale comparisons
    labels=['Low-promotion','Other ad week','Candidate big-sale']
    qr=q4.set_index(['week_type','on_sale_inferred'])
    xx=np.arange(3)
    for field,title,ylab,fn in [
        ('opening_zero_pct','Q4: Zero opening-stock rate — on sale vs. not on sale',
         'Store-product-days with zero opening stock (%)','q4_on_vs_off_sale_zero_stock.png'),
        ('mean_received_units','Q4: Deliveries — on sale vs. not on sale',
         'Received units per store-product-day','q4_on_vs_off_sale_deliveries.png'),
        ('mean_opening_stock','Q4: Opening inventory — on sale vs. not on sale',
         'Mean opening units per store-product-day','q4_on_vs_off_sale_opening_units.png')]:
        fig,ax=plt.subplots(figsize=(11,5.5))
        for i,(v,lab) in enumerate([(False,'Not on sale (inferred)'),(True,'On sale (inferred)')]):
            ys=[qr.loc[(w,v),field] for w in labels]
            rects=ax.bar(xx+(-.2 if i==0 else .2),ys,width=.38,label=lab)
            ax.bar_label(rects,fmt='%.2f',padding=2,fontsize=9)
        ax.set_xticks(xx,labels);ax.set_ylabel(ylab);ax.set_title(title)
        ax.legend();ax.set_ylim(bottom=0);fig.tight_layout()
        fig.savefig(out/fn,dpi=170);plt.close(fig)
    # Q5 week by week: holiday weeks marked on the line
    fig,ax=plt.subplots(figsize=(13,5.5))
    ix=np.arange(len(weekly))
    ax.plot(ix,weekly.margin_rate_pct,label='Gross margin rate',linewidth=1.7)
    major=weekly.major_holiday_week
    ax.scatter(ix[major],weekly.loc[major,'margin_rate_pct'],marker='o',s=40,
               label='Week containing selected major holiday',zorder=4)
    for j,r in weekly.loc[major].iterrows():
        if 'Thanksgiving' in r.major_holiday_names or 'Christmas' in r.major_holiday_names:
            ax.annotate(f"{r.major_holiday_names} {str(r.ad_week)[:4]}",
                        (j,r.margin_rate_pct),xytext=(0,9),textcoords='offset points',
                        ha='center',fontsize=7,rotation=25)
    ax.set_xticks(ix[::8],weekly.ad_week.astype(str).iloc[::8],rotation=35)
    ax.set_ylabel('Gross margin rate (%)')
    ax.set_xlabel('Ad week (Wednesday–Tuesday)')
    ax.set_title('Q5: Margin by week; selected holiday ad weeks highlighted')
    ax.legend();fig.tight_layout()
    fig.savefig(out/'q5_weekly_margin_holidays.png',dpi=170);plt.close(fig)
    # Q5 by holiday and sale breadth (store-day total margin), answers 'only holidays?'
    piv=q5h.pivot(index='week_type',columns='major_holiday_week',values='mean_gross_margin_per_store_day').reindex(labels)
    fig,ax=plt.subplots(figsize=(11,5.5))
    for i,(val,lab) in enumerate([(False,'Other weeks'),(True,'Major holiday weeks')]):
        ys=piv[val].values
        rects=ax.bar(xx+(-.2 if i==0 else .2),ys,width=.38,label=lab)
        ax.bar_label(rects,fmt='$%.0f',padding=2,fontsize=9)
    ax.set_xticks(xx,labels)
    ax.set_ylabel('Mean gross margin ($) per store-open-day')
    ax.set_title('Q5: Margin by inferred promotion intensity and holidays')
    ax.set_ylim(bottom=0);ax.legend();fig.tight_layout()
    fig.savefig(out/'q5_holiday_vs_nonholiday_by_promotion.png',dpi=170);plt.close(fig)
    fig,ax=plt.subplots(figsize=(10,5))
    qs=q5.set_index('week_type').reindex(TYPE_ORDER)
    rects=ax.bar(TYPE_ORDER,qs.gross_margin_rate_pct)
    ax.bar_label(rects,fmt='%.2f%%',padding=3)
    ax.set_ylabel('Gross margin rate (%)')
    ax.set_title('Q5: Gross margin rate by inferred promotion intensity')
    ax.set_ylim(bottom=0);fig.tight_layout()
    fig.savefig(out/'q5_margin_rate_by_sale_breadth.png',dpi=170);plt.close(fig)

    print('\nQ4: both inferred sale statuses',flush=True)
    print(q4[['week_type','on_sale_inferred','product_days','opening_zero_pct','mean_opening_stock','mean_received_units']].to_string(index=False),flush=True)
    print('\nQ5: holiday vs. other within promotion types',flush=True)
    print(q5h[['major_holiday_week','week_type','store_open_days','mean_gross_margin_per_store_day','gross_margin_rate_pct']].to_string(index=False),flush=True)
    print('\nQ5: all weeks and holiday totals',flush=True)
    print(q5b.to_string(index=False),flush=True)
    print(f'\nResults saved to: {out}',flush=True)

if __name__=='__main__':
    main()
